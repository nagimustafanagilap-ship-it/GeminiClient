package com.gemini.client;

import com.gemini.client.hud.FPSModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class GeminiClient implements ClientModInitializer {
    public static final String MOD_ID = "geminiclient";

    @Override
    public void onInitializeClient() {
        // تشغيل الـ FPS على الشاشة فوراً
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            FPSModule.render(drawContext, net.minecraft.client.MinecraftClient.getInstance());
        });
    }
}
