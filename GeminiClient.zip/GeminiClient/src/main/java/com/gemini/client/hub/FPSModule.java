package com.gemini.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FPSModule {
    public static void render(DrawContext drawContext, MinecraftClient client) {
        if (client.options.hudHidden || client.currentScreen != null) return;
        
        int currentFps = client.getCurrentFps();
        String fpsText = "§bGemini §7| §f" + currentFps + " FPS";
        
        // رسم النص بالزاوية فوق باليسار
        drawContext.drawText(client.textRenderer, fpsText, 5, 5, 0xFFFFFFFF, true);
    }
}
